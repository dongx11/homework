#ifndef __LED_H
#define __LED_H


#include  "stm32f10x.h"


#define LED0_ON GPIO_ResetBits(GPIOC,GPIO_Pin_0)//��
#define LED0_OFF GPIO_SetBits(GPIOC,GPIO_Pin_0)//��
#define LED1_ON GPIO_ResetBits(GPIOC,GPIO_Pin_1)//��
#define LED1_OFF GPIO_SetBits(GPIOC,GPIO_Pin_1)//��

#define LED0_REV GPIO_WriteBit(GPIOC,GPIO_Pin_0,(BitAction)(1-GPIO_ReadOutputDataBit(GPIOC, GPIO_Pin_0)))
#define LED1_REV GPIO_WriteBit(GPIOC,GPIO_Pin_1,(BitAction)(1-GPIO_ReadOutputDataBit(GPIOC, GPIO_Pin_1)))

void LED_Config(void);//����



#endif
