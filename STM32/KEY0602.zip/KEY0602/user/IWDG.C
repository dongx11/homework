#include "iwdg.h"
#include "stm32f10x.h"
void IWDG_Config(){
	IWDG_WriteAccessCmd(IWDG_WriteAccess_Enable);
	
	
	
}