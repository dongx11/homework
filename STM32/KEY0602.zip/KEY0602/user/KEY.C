#include "key.h"
#include "delay.h"
void KEY_Config(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC|RCC_APB2Periph_GPIOD, ENABLE);

	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_IPU;
	GPIO_InitStructure.GPIO_Pin=GPIO_Pin_8|GPIO_Pin_9;
  GPIO_Init(GPIOC,&GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_IPU;
	GPIO_InitStructure.GPIO_Pin=GPIO_Pin_2;
	GPIO_Init(GPIOD,&GPIO_InitStructure);


}
uint8_t KEY_Scan(void)
{
	static  uint8_t key_up=1;
	if(key_up&&(KEY0==0||KEY1==0||KEY2==0))
	{
	   delay_ms(10);
		key_up=0;
		if(KEY0 ==0) return 1;
		else if(KEY1 ==0) return 2;
		else if(KEY2 ==0) return 3;
	}
	else if(KEY0==1&&KEY1==1&&KEY2==1)
		key_up=1;
	return 0;
		
	
}



