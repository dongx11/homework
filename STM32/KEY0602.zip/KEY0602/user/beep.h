#ifndef __BEEP_H
#define __BEEP_H

#define BEEP_ON GPIO_ResetBits(GPIOB, GPIO_Pin_8)
#define BEEP_OFF GPIO_SetBits(GPIOB, GPIO_Pin_8)
#define BEEP_REV GPIO_WriteBit(GPIOB,GPIO_Pin_8,(BitAction)(1-GPIO_ReadOutputDataBit(GPIOB, GPIO_Pin_8)))
void BEEP_Config(void);
#endif

